package br.univille.estd.stacks.reverse;

public class StackUtils {
	
	public static <E> void reverse(E[] a) {
		a = null;
	}

}
