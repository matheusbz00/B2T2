package br.univille.estd.stacks.array;

class FullStackException extends RuntimeException {
	
	public FullStackException(String error) {
		super(error);
	}

}
